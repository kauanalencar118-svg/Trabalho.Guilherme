# Sistema de Controle de Pedidos — Lanchonete

## Tabelas Identificadas

### 1. `Produto`
Armazena os itens vendidos na lanchonete.

| Campo       | Tipo    | Descrição                        |
|-------------|---------|----------------------------------|
| id          | int     | Identificador único do produto   |
| nome        | String  | Nome do produto                  |
| descricao   | String  | Descrição do produto             |
| preco       | double  | Preço unitário do produto        |

### 2. `Pedido`
Registra os pedidos realizados pelos clientes.

| Campo        | Tipo            | Descrição                              |
|--------------|-----------------|----------------------------------------|
| id           | int             | Identificador único do pedido          |
| dataHora     | LocalDateTime   | Data e hora em que o pedido foi feito  |
| itens        | List<ItemPedido>| Lista de itens do pedido               |
| status       | String          | Status do pedido (ABERTO / FINALIZADO) |

### 3. `ItemPedido`
Representa a associação entre um pedido e um produto (com quantidade).

| Campo      | Tipo    | Descrição                        |
|------------|---------|----------------------------------|
| produto    | Produto | Produto associado ao item        |
| quantidade | int     | Quantidade do produto no pedido  |

---

## Regras de Negócio Identificadas

1. **Nome do produto não pode ser vazio** — ao cadastrar um produto, o nome é obrigatório.
2. **Preço do produto não pode ser negativo** — o preço deve ser maior que zero.
3. **Um pedido só pode ser finalizado se tiver pelo menos um produto adicionado** — pedidos vazios não podem ser concluídos.
4. **O valor total do pedido é calculado automaticamente** — soma de (preço × quantidade) de todos os itens.
5. **Consulta de pedidos por data** — deve ser possível filtrar pedidos por uma data específica.
6. **Faturamento por período** — o sistema deve somar os totais dos pedidos de um determinado dia.

---

## Projetos

| Projeto               | Branch / Pasta            | Descrição                                   |
|-----------------------|---------------------------|---------------------------------------------|
| `lanchonete-simples`  | `main` / pasta simples    | Classes e relacionamentos sem padrão MVC    |
| `lanchonete-mvc`      | `mvc`  / pasta mvc        | Refatoração com padrão MVC                  |
