package lanchonete;

import lanchonete.controller.PedidoController;
import lanchonete.controller.ProdutoController;
import lanchonete.model.Pedido;
import lanchonete.model.Produto;
import lanchonete.view.PedidoView;

import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // --- Instâncias MVC ---
        ProdutoController produtoController = new ProdutoController();
        PedidoController  pedidoController  = new PedidoController();
        PedidoView        view              = new PedidoView();

        view.exibirCabecalho();

        // --- Cadastro de Produtos ---
        view.exibirMensagem(">>> Cadastrando produtos...");
        Produto xBurguer = produtoController.cadastrar("X-Burguer",      "Pão, carne, queijo e alface", 18.50);
        Produto suco     = produtoController.cadastrar("Suco de Laranja", "Suco natural 300ml",           7.00);
        Produto fritas   = produtoController.cadastrar("Batata Frita",    "Porção média de batata frita", 12.00);
        Produto cafe     = produtoController.cadastrar("Café",            "Café coado 150ml",              4.50);

        view.exibirProdutosCadastrados(produtoController.listarTodos());

        // --- Validação: preço negativo ---
        view.exibirMensagem(">>> Tentando cadastrar produto com preço negativo...");
        try {
            produtoController.cadastrar("Produto Inválido", "Desc", -5.00);
        } catch (IllegalArgumentException e) {
            view.exibirErroCriacao(e.getMessage());
        }

        // --- Validação: nome vazio ---
        view.exibirMensagem("\n>>> Tentando cadastrar produto com nome vazio...");
        try {
            produtoController.cadastrar("", "Sem nome", 10.00);
        } catch (IllegalArgumentException e) {
            view.exibirErroCriacao(e.getMessage());
        }

        // --- Pedido 1 ---
        view.exibirMensagem("\n>>> Criando Pedido 1...");
        Pedido pedido1 = pedidoController.criarPedido();
        pedidoController.adicionarItem(pedido1, xBurguer, 2);
        pedidoController.adicionarItem(pedido1, suco, 2);
        pedidoController.adicionarItem(pedido1, fritas, 1);
        pedidoController.finalizarPedido(pedido1);
        view.exibirPedido(pedido1);

        // --- Pedido 2 ---
        view.exibirMensagem(">>> Criando Pedido 2...");
        Pedido pedido2 = pedidoController.criarPedido();
        pedidoController.adicionarItem(pedido2, cafe, 3);
        pedidoController.finalizarPedido(pedido2);
        view.exibirPedido(pedido2);

        // --- Validação: pedido sem itens ---
        view.exibirMensagem(">>> Tentando finalizar pedido sem itens...");
        try {
            Pedido vazio = pedidoController.criarPedido();
            pedidoController.finalizarPedido(vazio);
        } catch (IllegalStateException e) {
            view.exibirErroCriacao(e.getMessage());
        }

        // --- Consulta por data e faturamento ---
        LocalDate hoje = LocalDate.now();
        System.out.println();
        List<Pedido> pedidosHoje = pedidoController.consultarPorData(hoje);
        view.exibirPedidosPorData(hoje, pedidosHoje);

        double faturamento = pedidoController.calcularFaturamento(hoje);
        view.exibirFaturamento(hoje, faturamento);

        view.exibirRodape();
    }
}
