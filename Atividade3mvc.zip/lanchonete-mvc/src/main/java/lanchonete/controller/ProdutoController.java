package lanchonete.controller;

import lanchonete.model.Produto;
import java.util.ArrayList;
import java.util.List;

public class ProdutoController {
    private List<Produto> produtos = new ArrayList<>();

    public Produto cadastrar(String nome, String descricao, double preco) {
        // Validações ficam no construtor do model; aqui centralizamos o fluxo
        Produto produto = new Produto(nome, descricao, preco);
        produtos.add(produto);
        return produto;
    }

    public List<Produto> listarTodos() {
        return produtos;
    }

    public Produto buscarPorId(int id) {
        for (Produto p : produtos) {
            if (p.getId() == id) return p;
        }
        return null;
    }
}
