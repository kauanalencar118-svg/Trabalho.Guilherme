package lanchonete.controller;

import lanchonete.model.ItemPedido;
import lanchonete.model.Pedido;
import lanchonete.model.Produto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PedidoController {
    private List<Pedido> pedidos = new ArrayList<>();

    public Pedido criarPedido() {
        return new Pedido();
    }

    public void adicionarItem(Pedido pedido, Produto produto, int quantidade) {
        ItemPedido item = new ItemPedido(produto, quantidade);
        pedido.adicionarItem(item);
    }

    public void finalizarPedido(Pedido pedido) {
        pedido.finalizar();
        pedidos.add(pedido);
    }

    public List<Pedido> consultarPorData(LocalDate data) {
        List<Pedido> resultado = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (p.isDestaData(data)) resultado.add(p);
        }
        return resultado;
    }

    public double calcularFaturamento(LocalDate data) {
        double total = 0;
        for (Pedido p : consultarPorData(data)) {
            total += p.calcularTotal();
        }
        return total;
    }

    public List<Pedido> listarTodos() {
        return pedidos;
    }
}
