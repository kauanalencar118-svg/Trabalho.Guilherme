package lanchonete.view;

import lanchonete.model.ItemPedido;
import lanchonete.model.Pedido;
import lanchonete.model.Produto;

import java.time.LocalDate;
import java.util.List;

public class PedidoView {

    public void exibirCabecalho() {
        System.out.println("========================================");
        System.out.println("  SISTEMA DE PEDIDOS — LANCHONETE (MVC)");
        System.out.println("========================================\n");
    }

    public void exibirProdutosCadastrados(List<Produto> produtos) {
        System.out.println("--- Produtos cadastrados ---");
        for (Produto p : produtos) {
            System.out.println("  " + p);
        }
        System.out.println();
    }

    public void exibirPedido(Pedido pedido) {
        System.out.printf("=== Pedido #%d | %s | Status: %s ===%n",
                pedido.getId(), pedido.getDataHora().toLocalDate(), pedido.getStatus());
        for (ItemPedido item : pedido.getItens()) {
            System.out.println(item);
        }
        System.out.printf("  TOTAL: R$ %.2f%n%n", pedido.calcularTotal());
    }

    public void exibirPedidosPorData(LocalDate data, List<Pedido> pedidos) {
        System.out.println("--- Pedidos em " + data + " ---");
        if (pedidos.isEmpty()) {
            System.out.println("  Nenhum pedido encontrado.");
        }
        for (Pedido p : pedidos) {
            System.out.printf("  Pedido #%d | Total: R$ %.2f%n",
                    p.getId(), p.calcularTotal());
        }
        System.out.println();
    }

    public void exibirFaturamento(LocalDate data, double valor) {
        System.out.printf(">>> Faturamento em %s: R$ %.2f%n%n", data, valor);
    }

    public void exibirErroCriacao(String mensagem) {
        System.out.println("ERRO capturado: " + mensagem);
    }

    public void exibirMensagem(String msg) {
        System.out.println(msg);
    }

    public void exibirRodape() {
        System.out.println("========================================");
    }
}
