package lanchonete.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private static int contadorId = 1;

    private int id;
    private LocalDateTime dataHora;
    private List<ItemPedido> itens;
    private String status;

    public Pedido() {
        this.id = contadorId++;
        this.dataHora = LocalDateTime.now();
        this.itens = new ArrayList<>();
        this.status = "ABERTO";
    }

    public void adicionarItem(ItemPedido item) {
        itens.add(item);
    }

    public void finalizar() {
        if (itens.isEmpty()) {
            throw new IllegalStateException("Não é possível finalizar um pedido sem produtos.");
        }
        this.status = "FINALIZADO";
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    public boolean isDestaData(LocalDate data) {
        return this.dataHora.toLocalDate().equals(data);
    }

    public int getId() { return id; }
    public LocalDateTime getDataHora() { return dataHora; }
    public List<ItemPedido> getItens() { return itens; }
    public String getStatus() { return status; }
}
