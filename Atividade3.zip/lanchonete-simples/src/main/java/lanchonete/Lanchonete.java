package lanchonete;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Lanchonete {
    private List<Produto> produtos;
    private List<Pedido> pedidos;

    public Lanchonete() {
        this.produtos = new ArrayList<>();
        this.pedidos = new ArrayList<>();
    }

    public void cadastrarProduto(Produto produto) {
        produtos.add(produto);
        System.out.println("Produto cadastrado: " + produto.getNome());
    }

    public void registrarPedido(Pedido pedido) {
        pedidos.add(pedido);
        System.out.println("Pedido #" + pedido.getId() + " registrado.");
    }

    public List<Pedido> consultarPedidosPorData(LocalDate data) {
        List<Pedido> resultado = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (p.isDestaData(data)) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public double calcularFaturamentoPorData(LocalDate data) {
        double total = 0;
        for (Pedido p : consultarPedidosPorData(data)) {
            total += p.calcularTotal();
        }
        return total;
    }

    public List<Produto> getProdutos() { return produtos; }
    public List<Pedido> getPedidos() { return pedidos; }
}
