package lanchonete;

import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("  SISTEMA DE PEDIDOS — LANCHONETE");
        System.out.println("========================================\n");

        Lanchonete lanchonete = new Lanchonete();

        // --- Cadastro de Produtos ---
        System.out.println(">>> Cadastrando produtos...");
        Produto xBurguer = new Produto("X-Burguer", "Pão, carne, queijo e alface", 18.50);
        Produto suco     = new Produto("Suco de Laranja", "Suco natural 300ml", 7.00);
        Produto fritas   = new Produto("Batata Frita", "Porção média de batata frita", 12.00);
        Produto cafe     = new Produto("Café", "Café coado 150ml", 4.50);

        lanchonete.cadastrarProduto(xBurguer);
        lanchonete.cadastrarProduto(suco);
        lanchonete.cadastrarProduto(fritas);
        lanchonete.cadastrarProduto(cafe);

        // --- Teste de validação: preço negativo ---
        System.out.println("\n>>> Tentando cadastrar produto com preço negativo...");
        try {
            Produto invalido = new Produto("Produto Ruim", "Desc", -5.00);
        } catch (IllegalArgumentException e) {
            System.out.println("ERRO capturado: " + e.getMessage());
        }

        // --- Teste de validação: nome vazio ---
        System.out.println("\n>>> Tentando cadastrar produto com nome vazio...");
        try {
            Produto semNome = new Produto("", "Sem nome", 10.00);
        } catch (IllegalArgumentException e) {
            System.out.println("ERRO capturado: " + e.getMessage());
        }

        // --- Pedido 1 ---
        System.out.println("\n>>> Criando Pedido 1...");
        Pedido pedido1 = new Pedido();
        pedido1.adicionarItem(xBurguer, 2);
        pedido1.adicionarItem(suco, 2);
        pedido1.adicionarItem(fritas, 1);
        pedido1.finalizar();
        lanchonete.registrarPedido(pedido1);
        System.out.println(pedido1);

        // --- Pedido 2 ---
        System.out.println("\n>>> Criando Pedido 2...");
        Pedido pedido2 = new Pedido();
        pedido2.adicionarItem(cafe, 3);
        pedido2.finalizar();
        lanchonete.registrarPedido(pedido2);
        System.out.println(pedido2);

        // --- Teste de validação: pedido vazio ---
        System.out.println("\n>>> Tentando finalizar pedido sem itens...");
        try {
            Pedido pedidoVazio = new Pedido();
            pedidoVazio.finalizar();
        } catch (IllegalStateException e) {
            System.out.println("ERRO capturado: " + e.getMessage());
        }

        // --- Consulta por data ---
        LocalDate hoje = LocalDate.now();
        System.out.println("\n>>> Pedidos realizados em " + hoje + ":");
        List<Pedido> pedidosHoje = lanchonete.consultarPedidosPorData(hoje);
        for (Pedido p : pedidosHoje) {
            System.out.println("  Pedido #" + p.getId() + " | Total: R$ " +
                    String.format("%.2f", p.calcularTotal()));
        }

        // --- Faturamento ---
        double faturamento = lanchonete.calcularFaturamentoPorData(hoje);
        System.out.printf("%n>>> Faturamento total em %s: R$ %.2f%n", hoje, faturamento);
        System.out.println("\n========================================");
    }
}
