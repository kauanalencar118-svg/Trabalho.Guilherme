package lanchonete;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private static int contadorId = 1;

    private int id;
    private LocalDateTime dataHora;
    private List<ItemPedido> itens;
    private String status;

    public Pedido() {
        this.id = contadorId++;
        this.dataHora = LocalDateTime.now();
        this.itens = new ArrayList<>();
        this.status = "ABERTO";
    }

    public void adicionarItem(Produto produto, int quantidade) {
        itens.add(new ItemPedido(produto, quantidade));
    }

    public void finalizar() {
        if (itens.isEmpty()) {
            throw new IllegalStateException("Não é possível finalizar um pedido sem produtos.");
        }
        this.status = "FINALIZADO";
    }

    public double calcularTotal() {
        double total = 0;
        for (ItemPedido item : itens) {
            total += item.getSubtotal();
        }
        return total;
    }

    public boolean isDestaData(LocalDate data) {
        return this.dataHora.toLocalDate().equals(data);
    }

    public int getId() { return id; }
    public LocalDateTime getDataHora() { return dataHora; }
    public List<ItemPedido> getItens() { return itens; }
    public String getStatus() { return status; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("=== Pedido #%d | %s | Status: %s ===\n",
                id, dataHora.toLocalDate(), status));
        for (ItemPedido item : itens) {
            sb.append(item.toString()).append("\n");
        }
        sb.append(String.format("  TOTAL: R$ %.2f", calcularTotal()));
        return sb.toString();
    }
}
